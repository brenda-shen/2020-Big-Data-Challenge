# twitter_covid-19
This repo is a dataset from covid-19 and diferents twitts 
