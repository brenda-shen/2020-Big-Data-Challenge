---
name: Question
about: Ask a question about the data or methodology
title: 'Question:  '
labels: question
assignees: ''

---

### Do you think there is an error in the data?
Please submit a Data Issue so it can be easily routed to the correct people.

### Do you have a question about the LICENSE or permission to use this data?
Please email us at covid-data@nytimes.com

### Your question
Please check to make sure your question is not answered in the README. It may have been updated since you first read it.
